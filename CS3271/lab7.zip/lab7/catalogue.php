<?php
  session_start();
  $count = 0;
  require_once "db_functions.php";
  require_once "conn.php";
  $conn = db_connect();
  $row = getAll($conn);
  $query = "SELECT book_isbn, book_image FROM books";
  $result = mysqli_query($conn, $query);
  if(!$result){
    echo "Can't retrieve data " . mysqli_error($conn);
    exit;
  }
  $title = "Full Catalogs of Books";
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
      body {
        background-color: #f8f9fa;
      }

      h2 {
        margin-top: 50px;
        text-align: center;
        font-weight: bold;
      }

      .card {
        margin: 10px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0px 2px 5px #ccc;
      }

      .card-img-top {
        height: 200px;
        object-fit: cover;
        border-radius: 5px 5px 0 0;
      }

      .card-body {
        padding: 10px;
      }

      .card-title {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 10px;
      }

      .btn-logout {
        margin-top: 20px;
      }
    </style>
    <title>Catalogue</title>
  </head>
  <body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="#">Book Store</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="catalogue.php">Books</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="logout.php">Logout</a>
          </li>
        </ul>
      </div>
    </nav>
    <div class="container">
      <h2>Latest Books</h2>
      <div class="row">
        <?php foreach($row as $book) { ?>
          <div class="col-md-3">
            <div class="card">
              <a href="book.php?bookisbn=<?php echo $book['book_isbn']; ?>">
                <img class="card-img-top" src="./images/<?php echo $book['book_image']; ?>">
              </a>
              <div class="card-body">
                <h5 class="card-title"><?php echo $book['book_title']; ?></h5>
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
    </div>
  </body>
</html>