<?php
  session_start();
  $book_isbn = $_GET['bookisbn'];
  require_once "./database_functions.php";
  $conn = db_connect();

  $query = "SELECT * FROM books WHERE book_isbn = '$book_isbn'";
  $result = mysqli_query($conn, $query);
  if(!$result){
    echo "Can't retrieve data " . mysqli_error($conn);
    exit;
  }

  $row = mysqli_fetch_assoc($result);
  if(!$row){
    echo "Empty book";
    exit;
  }

  $title = $row['book_title'];
?>
<!DOCTYPE html>
<html>
<head>
  <title><?php echo $title; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <style>
    .row {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-direction: column;
    }
    .book-image {
      width: 100%;
      max-width: 300px;
      height: auto;
      margin: 0 auto;
      display: block;
    }
    .book-details {
      margin-top: 25px;
      width: 100%;
      max-width: 600px;
      border-collapse: collapse;
    }
    .book-details th {
      text-align: left;
      padding: 10px;
      background-color: #f2f2f2;
    }
    .book-details td {
      padding: 10px;
      border-bottom: 1px solid #ddd;
    }
    .book-details td:first-child {
      font-weight: bold;
    }
    .back-to-catalogue {
      display: block;
      margin-top: 20px;
      font-size: 16px;
      color: #333;
      text-decoration: none;
      text-align: center;
    }
    .back-to-catalogue:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <p class="lead" style="margin: 25px 0"><a href="catalogue.php">Books</a> > <?php echo $row['book_title']; ?></p>
    <div class="row">
      <div class="col-md-3 text-center">
        <img class="book-image img-responsive img-thumbnail" src="./images/<?php echo $row['book_image']; ?>">
      </div>
      <div class="col-md-6">
        <h4>Book Description</h4>
        <p><?php echo $row['book_descr']; ?></p>
        <h4>Book Details</h4>
        <table class="table book-details">
          <?php foreach($row as $key => $value){
            if($key == "book_descr" || $key == "book_image" || $key == "publisherid" || $key == "book_title"){
              continue;
            }
            switch($key){
              case "book_isbn":
                $key = "ISBN";
                  break;
                case "book_title":
                  $key = "Title";
                  break;
                case "book_author":
                  $key = "Author";
                  break;
                case "book_price":
                  $key = "Price";
                  break;
              }
            ?>
            <tr>
              <td><?php echo $key; ?></td>
              <td><?php echo $value; ?></td>
            </tr>
            <?php 
              } 
              if(isset($conn)) {mysqli_close($conn); }
            ?>
          </table>
       	</div>
      </div>
</html>