<!DOCTYPE html>
<html>
<head>
	<title>Registration Page</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<style>
		body {
			font-family: Arial, sans-serif;
			background-color: #f2f2f2;
		}
		.container {
			background-color: #fff;
			padding: 20px;
			margin: auto;
			margin-top: 50px;
			width: 50%;
			box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
		}
		h1 {
			text-align: center;
			margin-bottom: 20px;
		}
		label {
			display: block;
			margin-bottom: 5px;
			font-weight: bold;
		}
		input[type="text"],
		input[type="email"],
		input[type="password"] {
			padding: 10px;
			border-radius: 5px;
			margin-bottom: 20px;
			width: 100%;
			border: 1px solid #ccc;
		}
		input[type="submit"] {
			background-color: #4CAF50;
			color: #fff;
			padding: 10px 20px;
			border: none;
			border-radius: 5px;
			cursor: pointer;
		}
		input[type="submit"]:hover {
			background-color: #3e8e41;
		}
		.form-control:focus {
			border-color: #4CAF50;
			box-shadow: none;
		}
	</style>
</head>
<body>
	<div class="container">
		<form action="signup_submission.php" method="post">
			<h1>Registration</h1>
			<div class="form-group">
				<label for="exampleInputEmail1">Username:</label>
				<input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="user_name" placeholder="Enter username">
			</div>
			<div class="form-group">
				<label for="exampleInputPassword1">Password:</label>
				<input type="password" class="form-control" id="exampleInputPassword1" name="pass_word" placeholder="Enter password">
			</div>
			<div class="form-group">
				<label for="exampleConfirmInputPassword1">Confirm Password:</label>
				<input type="password" class="form-control" id="exampleInputPassword2" name="confirm_password" placeholder="Confirm password">
			</div>
			<center><button type="submit" class="btn btn-primary">Register</button></center>
		</form>
	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
